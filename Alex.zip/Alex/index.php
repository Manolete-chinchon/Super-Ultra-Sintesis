<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TruePlayer</title>
    <link rel="icon" type="image/png" href="Img/Icono Trueplayer.png">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <!-- Header -->
    <header>
    <nav class="navbar">
        <div class="logo">
            <img src="Img/Icono Trueplayer.png">
            <div class="titulo"><h1>TruePlayer</h1></div>
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="productos.html">Productos</a></li>
            <li><a href="#contacto">Contacto</a></li>
        </ul>
        <div class="user-icon">
            <?php if (isset($_SESSION['nombre_usuario'])): ?>
                <!-- Dropdown para usuario logueado -->
                <div class="dropdown">
                    <button class="dropbtn">👤 <?php echo htmlspecialchars($_SESSION['nombre_usuario']); ?> ▼</button>
                    <div class="dropdown-content">
                        <a href="#">Mi Perfil</a>
                        <a href="#">Mis Compras</a>
                        <a href="logout.php">Cerrar sesión</a>
                    </div>
                </div>
            <?php else: ?>
                <!-- Si no está logueado, mostrar botón de iniciar sesión -->
                <a href="login.html"><img src="Img/iniciosesion.png" alt="Iniciar sesión"></a>
            <?php endif; ?>
        </div>
    </nav>
</header>


    <!-- Sección Hero -->
    <section id="inicio" class="hero">
        <div class="hero-content">
            <!-- Card del zapato -->
            <div class="shoe-card" style="--delay: 0.5538666555521905s;">
                <img src="Img/fortnite.png" alt="Zapato destacado">
                <div class="shoe-info">
                    <h3>Zapato del Mes</h3>
                    <p class="price">$55</p>
                </div>
                <div class="glow-overlay"></div>
            </div>
            <div class="hero-text">
                <h1>Descubre el estilo perfecto para cada paso</h1>
                <a href="productos.html"><button class="btn">Ver catálogo</button></a>
            </div>
        </div>
    </section>

    <!-- Sección de Destacados -->
    <section id="catalogo" class="destacados">
        <h2>Zapatos Populares</h2>
        <div class="carousel">
            <button class="carousel-button prev" aria-label="Anterior">❮</button>
            <div class="carousel-container">
                <div class="carousel-track" style="transform: translateX(0px);">
                    <div class="carousel-card" style="--delay: 0.6228819646355208s;">
                        <img src="Img/freefire.png" alt="Zapato 1">
                        <h3>Zapato 1</h3>
                        <p class="precio">$50</p>
                        <div class="glow-overlay"></div>
                    </div>
                    <div class="carousel-card" style="--delay: 1.542333316249536s;">
                        <img src="Img/messi.png" alt="Zapato 2">
                        <h3>Zapato 2</h3>
                        <p class="precio">$40</p>
                        <div class="glow-overlay"></div>
                    </div>
                    <div class="carousel-card" style="--delay: 0.6376967089672094s;">
                        <img src="Img/arthur.png" alt="Zapato 3">
                        <h3>Zapato 3</h3>
                        <p class="precio">$60</p>
                        <div class="glow-overlay"></div>
                    </div>
                    <div class="carousel-card" style="--delay: 1.7799276030847109s;">
                        <img src="Img/fallout.png" alt="Zapato 4">
                        <h3>Zapato 4</h3>
                        <p class="precio">$55</p>
                        <div class="glow-overlay"></div>
                    </div>
                    <div class="carousel-card" style="--delay: 1.5696877191057674s;">
                        <img src="Img/transformers.png" alt="Zapato 5">
                        <h3>Zapato 5</h3>
                        <p class="precio">$45</p>
                        <div class="glow-overlay"></div>
                    </div>
                </div>
            </div>
            <button class="carousel-button next" aria-label="Siguiente">❯</button>
        </div>
    </section>

    <!-- Beneficios -->
    <section class="beneficios">
        <h2>¿Por qué comprar con nosotros?</h2>
        <ul>
            <li>🚚 Envío rápido</li>
            <li>💳 Pagos seguros</li>
            <li>🔄 Devoluciones fáciles</li>
        </ul>
    </section>

    <!-- Opiniones -->
    <section class="opiniones">
        <h2>Opiniones de Clientes</h2>
        <p>⭐⭐⭐⭐⭐ "Los mejores zapatos, excelente calidad!"</p>
    </section>

    <!-- Footer -->
    <footer>
        <p>© 2025 TiendaZap. Todos los derechos reservados.</p>
    </footer>

    <script src="js/codigo.js"></script>
</body>
</html>
