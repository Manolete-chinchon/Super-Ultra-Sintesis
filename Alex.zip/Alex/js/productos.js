// Script para la página de productos
document.addEventListener('DOMContentLoaded', function() {
    // Filtros de productos
    const filterButtons = document.querySelectorAll('.filter-btn');
    const productCards = document.querySelectorAll('.product-card');
    const sortSelect = document.getElementById('sort-options');
    const loadMoreBtn = document.getElementById('load-more-btn');
    
    // Escuchar clics en botones de filtro
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Eliminar clase 'active' de todos los botones
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Agregar clase 'active' al botón actual
            this.classList.add('active');
            
            // Obtener el filtro seleccionado
            const filter = this.getAttribute('data-filter');
            
            // Filtrar los productos
            filterProducts(filter);
        });
    });
    
    // Función para filtrar productos
    function filterProducts(filter) {
        productCards.forEach(card => {
            if (filter === 'todos') {
                card.style.display = 'block';
                
                // Añadir efecto de entrada con retraso aleatorio
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, Math.random() * 300);
            } else {
                if (card.getAttribute('data-category') === filter) {
                    card.style.display = 'block';
                    
                    // Añadir efecto de entrada con retraso aleatorio
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, Math.random() * 300);
                } else {
                    card.style.display = 'none';
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                }
            }
        });
    }
    
    // Escuchar cambios en el selector de ordenación
    sortSelect.addEventListener('change', function() {
        const sortType = this.value;
        sortProducts(sortType);
    });
    
    // Función para ordenar productos
    function sortProducts(sortType) {
        const productsArray = Array.from(productCards);
        
        // Ordenar según el criterio seleccionado
        switch(sortType) {
            case 'newest':
                // Podríamos tener una data-date pero para este ejemplo usaremos orden aleatorio
                shuffleArray(productsArray);
                break;
            case 'price-low':
                productsArray.sort((a, b) => {
                    const priceA = parseFloat(a.querySelector('.product-price').textContent.replace('€', ''));
                    const priceB = parseFloat(b.querySelector('.product-price').textContent.replace('€', ''));
                    return priceA - priceB;
                });
                break;
            case 'price-high':
                productsArray.sort((a, b) => {
                    const priceA = parseFloat(a.querySelector('.product-price').textContent.replace('€', ''));
                    const priceB = parseFloat(b.querySelector('.product-price').textContent.replace('€', ''));
                    return priceB - priceA;
                });
                break;
            case 'popular':
                // Para este ejemplo, usaremos orden aleatorio
                shuffleArray(productsArray);
                break;
        }
        
        // Reordenar visualmente en el DOM
        const productsGrid = document.querySelector('.products-grid');
        productsArray.forEach(product => {
            productsGrid.appendChild(product);
        });
        
        // Aplicar animación a los productos reordenados
        productsArray.forEach((product, index) => {
            product.style.opacity = '0';
            product.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                product.style.opacity = '1';
                product.style.transform = 'translateY(0)';
            }, 100 * index);
        });
    }
    
    // Función para mezclar un array (para ordenación aleatoria)
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
    
    // Simular carga de más productos
    loadMoreBtn.addEventListener('click', function() {
        // Cambiar texto al botón para indicar carga
        this.textContent = 'Cargando...';
        this.disabled = true;
        
        // Simular tiempo de carga
        setTimeout(() => {
            // Clonar productos existentes para simular nuevos productos
            productCards.forEach(card => {
                const clone = card.cloneNode(true);
                
                // Cambiar ligeramente algunos datos para simular que son diferentes
                const price = parseFloat(clone.querySelector('.product-price').textContent.replace('€', ''));
                const newPrice = (price - 10 + Math.random() * 20).toFixed(2);
                clone.querySelector('.product-price').textContent = '€' + newPrice;
                
                // Añadir al grid con animación
                clone.style.opacity = '0';
                clone.style.transform = 'translateY(20px)';
                document.querySelector('.products-grid').appendChild(clone);
                
                // Mostrar con animación
                setTimeout(() => {
                    clone.style.opacity = '1';
                    clone.style.transform = 'translateY(0)';
                }, Math.random() * 500);
            });
            
            // Restaurar botón
            this.textContent = 'Cargar más productos';
            this.disabled = false;
            
            // Aplicar filtro actual
            const activeFilter = document.querySelector('.filter-btn.active').getAttribute('data-filter');
            filterProducts(activeFilter);
            
            // Añadir eventos a los nuevos productos
            setupProductInteractions();
        }, 1500);
    });
    
    // Función para configurar interacciones en los productos
    function setupProductInteractions() {
        // Efecto hover para las imágenes de productos
        document.querySelectorAll('.product-card').forEach(card => {
            const img = card.querySelector('img');
            card.addEventListener('mouseenter', () => {
                img.style.transform = 'scale(1.1)';
            });
            card.addEventListener('mouseleave', () => {
                img.style.transform = 'scale(1)';
            });
        });
        
        // Efecto hover para vista rápida
        document.querySelectorAll('.quick-view').forEach(view => {
            view.addEventListener('mouseenter', () => {
                view.style.background = 'rgba(0, 255, 170, 0.3)';
                view.style.color = 'var(--primary-color)';
            });
            view.addEventListener('mouseleave', () => {
                view.style.background = 'rgba(0, 0, 0, 0.7)';
                view.style.color = 'var(--text-color)';
            });
        });
        
        // Interacción con los puntos de color
        document.querySelectorAll('.color-dot').forEach(dot => {
            dot.addEventListener('click', function() {
                // Seleccionar este color
                const parent = this.closest('.product-colors');
                parent.querySelectorAll('.color-dot').forEach(d => {
                    d.style.transform = 'scale(1)';
                    d.style.boxShadow = '0 0 5px rgba(0, 0, 0, 0.3)';
                });
                
                this.style.transform = 'scale(1.2)';
                this.style.boxShadow = '0 0 8px rgba(255, 255, 255, 0.5)';
            });
        });
    }
    
    // Inicializar interacciones
    setupProductInteractions();
    
    // Añadir efectos ciberpunk adicionales
    function addCyberpunkEffects() {
        // Efecto de desplazamiento para el héroe
        window.addEventListener('scroll', function() {
            const scrollPosition = window.scrollY;
            const heroImage = document.querySelector('.hero-image img');
            const heroContent = document.querySelector('.hero-content');
            
            if (heroImage && heroContent) {
                heroImage.style.transform = `rotate(-10deg) translateY(${scrollPosition * 0.1}px)`;
                heroContent.style.transform = `translateY(${scrollPosition * 0.05}px)`;
            }
        });
        
        // Efecto de parpadeo neón para textos destacados
        const highlightTexts = document.querySelectorAll('.highlight-text');
        highlightTexts.forEach(text => {
            setInterval(() => {
                const currentOpacity = parseFloat(window.getComputedStyle(text).getPropertyValue('opacity'));
                text.style.opacity = currentOpacity > 0.8 ? '0.8' : '1';
                
                const currentShadow = text.style.textShadow;
                const shadowIntensity = currentShadow.includes('15px') ? '10px' : '15px';
                text.style.textShadow = `0 0 ${shadowIntensity} var(--primary-color)`;
            }, 2000 + Math.random() * 1000);
        });
        
        // Animación para botones CTA
        const ctaButtons = document.querySelectorAll('.cta-button');
        ctaButtons.forEach(button => {
            setInterval(() => {
                button.classList.add('pulse');
                setTimeout(() => {
                    button.classList.remove('pulse');
                }, 1000);
            }, 5000);
        });
    }
    
    // Iniciar efectos cyberpunk
    addCyberpunkEffects();
    
    // Añadir estilos adicionales para animaciones
    const style = document.createElement('style');
    style.textContent = `
        @keyframes pulse {
            0% { box-shadow: 0 0 20px rgba(0, 255, 170, 0.6); }
            50% { box-shadow: 0 0 40px rgba(0, 255, 170, 0.8); }
            100% { box-shadow: 0 0 20px rgba(0, 255, 170, 0.6); }
        }
        
        .pulse {
            animation: pulse 1s ease-in-out;
        }
        
        .product-card {
            opacity: 1;
            transform: translateY(0);
            transition: opacity 0.5s, transform 0.5s;
        }
    `;
    document.head.appendChild(style);
});