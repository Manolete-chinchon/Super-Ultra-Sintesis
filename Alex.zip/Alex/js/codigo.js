document.addEventListener('DOMContentLoaded', function() {
    // Initialize the carousel
    initCarousel();
    
    // Add hover effects and animations
    enhanceVisuals();
});

function initCarousel() {
    const track = document.querySelector('.carousel-track');
    const cards = document.querySelectorAll('.carousel-card');
    const prevButton = document.querySelector('.carousel-button.prev');
    const nextButton = document.querySelector('.carousel-button.next');
    
    if (!track || !cards.length || !prevButton || !nextButton) return;
    
    let cardIndex = 0;
    const cardWidth = cards[0].offsetWidth;
    const cardMargin = parseInt(window.getComputedStyle(cards[0]).marginRight) || 0;
    const cardTotal = cards.length;
    
    // Calculate how many cards to show based on viewport width
    const getVisibleCards = () => {
        const containerWidth = document.querySelector('.carousel-container').offsetWidth;
        return Math.max(1, Math.floor(containerWidth / (cardWidth + cardMargin)));
    };
    
    let visibleCards = getVisibleCards();
    
    // Update carousel position
    const updateCarousel = () => {
        const gap = parseInt(window.getComputedStyle(track).columnGap) || 32; // Default 2rem = 32px
        track.style.transform = `translateX(-${cardIndex * (cardWidth + gap)}px)`;
    };
    
    // Handle next button click
    nextButton.addEventListener('click', () => {
        visibleCards = getVisibleCards();
        if (cardIndex < cardTotal - visibleCards) {
            cardIndex++;
            updateCarousel();
        } else {
            // Bounce effect for end of carousel
            track.style.transform = `translateX(-${cardIndex * (cardWidth + 32) + 20}px)`;
            setTimeout(() => {
                track.style.transform = `translateX(-${cardIndex * (cardWidth + 32)}px)`;
            }, 200);
        }
    });
    
    // Handle previous button click
    prevButton.addEventListener('click', () => {
        if (cardIndex > 0) {
            cardIndex--;
            updateCarousel();
        } else {
            // Bounce effect for start of carousel
            track.style.transform = `translateX(20px)`;
            setTimeout(() => {
                track.style.transform = `translateX(0)`;
            }, 200);
        }
    });
    
    // Handle window resize
    window.addEventListener('resize', () => {
        visibleCards = getVisibleCards();
        if (cardIndex > cardTotal - visibleCards) {
            cardIndex = Math.max(0, cardTotal - visibleCards);
        }
        updateCarousel();
    });
    
    // Initialize carousel
    updateCarousel();
}

function enhanceVisuals() {
    // Add glow effects to product cards
    const cards = document.querySelectorAll('.shoe-card, .carousel-card');
    
    cards.forEach(card => {
        // Create visual effect overlays
        const glowOverlay = document.createElement('div');
        glowOverlay.className = 'glow-overlay';
        card.appendChild(glowOverlay);
        
        // Add random delay to glow animations to create cyberpunk effect
        card.style.setProperty('--delay', `${Math.random() * 2}s`);
        
        // Interactive hover effects
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            // Calculate gradient position based on mouse
            const centerX = (x / rect.width) * 100;
            const centerY = (y / rect.height) * 100;
            
            // Apply glow effect following mouse
            glowOverlay.style.background = `radial-gradient(circle at ${centerX}% ${centerY}%, 
                                           rgba(0, 255, 170, 0.15) 0%, 
                                           transparent 70%)`;
        });
        
        card.addEventListener('mouseleave', () => {
            glowOverlay.style.background = 'none';
        });
    });
    
    // Add menu hover effects
    const menuItems = document.querySelectorAll('.nav-links a');
    
    menuItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            // Add a subtle electronic sound effect
            const hoverSound = new Audio();
            hoverSound.volume = 0.1;
            
            // Create a short beep using Web Audio API instead of audio file
            try {
                const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioCtx.createOscillator();
                const gainNode = audioCtx.createGain();
                
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(1800, audioCtx.currentTime);
                gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
                
                oscillator.connect(gainNode);
                gainNode.connect(audioCtx.destination);
                
                oscillator.start();
                oscillator.stop(audioCtx.currentTime + 0.1);
            } catch (e) {
                // Fall back silently if audio context isn't available
                console.log("Audio hover effect not available");
            }
        });
    });
    
    // Add text typing animation to title
    animateHeroText();
}

function animateHeroText() {
    const heroTitle = document.querySelector('.hero-text h1');
    if (!heroTitle) return;
    
    const originalText = heroTitle.textContent;
    heroTitle.textContent = '';
    
    let textIndex = 0;
    
    function typeText() {
        if (textIndex < originalText.length) {
            heroTitle.textContent += originalText.charAt(textIndex);
            textIndex++;
            setTimeout(typeText, Math.random() * 50 + 30);
        }
    }
    
    // Start typing animation
    setTimeout(typeText, 500);
}
