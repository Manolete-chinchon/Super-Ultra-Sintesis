// Script para la página de login
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('login-form');
    const errorMessage = document.getElementById('error-message');

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        errorMessage.textContent = '';

        const email = document.getElementById('email');
        const password = document.getElementById('password');

        if (!email.value || !password.value) {
            errorMessage.textContent = 'Por favor, completa todos los campos';
            if (!email.value) email.classList.add('input-error');
            if (!password.value) password.classList.add('input-error');
        } else {
            // Aquí normalmente manejarías la lógica de inicio de sesión
            console.log('Inicio de sesión enviado', {
                email: email.value,
                password: password.value,
                remember: document.getElementById('remember').checked
            });
            
            // Redirigir a la página principal tras iniciar sesión
            window.location.href = 'index.html';
        }
    });

    // Remover clase de error en input
    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', function () {
            this.classList.remove('input-error');
            errorMessage.textContent = '';
        });
    });
});