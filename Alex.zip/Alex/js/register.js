// Script para la página de registro
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('register-form');
    const errorMessage = document.getElementById('error-message');

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        errorMessage.textContent = '';
        
        // Obtener todos los campos
        const nombre = document.getElementById('nombre');
        const apellidos = document.getElementById('apellidos');
        const email = document.getElementById('email');
        const password = document.getElementById('password');
        const repasswd = document.getElementById('repasswd');
        
        // Reset de las clases de error
        document.querySelectorAll('input').forEach(input => {
            input.classList.remove('input-error');
        });
        
        // Validación de campos
        let hasError = false;
        
        if (!nombre.value) {
            nombre.classList.add('input-error');
            hasError = true;
        }
        
        if (!apellidos.value) {
            apellidos.classList.add('input-error');
            hasError = true;
        }
        
        if (!email.value) {
            email.classList.add('input-error');
            hasError = true;
        }
        
        if (!password.value) {
            password.classList.add('input-error');
            hasError = true;
        }
        
        if (!repasswd.value) {
            repasswd.classList.add('input-error');
            hasError = true;
        }
        
        if (hasError) {
            errorMessage.textContent = 'Por favor, completa todos los campos';
            return;
        }
        
        // Verificar que las contraseñas coincidan
        if (password.value !== repasswd.value) {
            password.classList.add('input-error');
            repasswd.classList.add('input-error');
            errorMessage.textContent = 'Las contraseñas no coinciden';
            return;
        }
        
        // Si todo está bien, proceder con el registro
        console.log('Registro enviado', {
            nombre: nombre.value,
            apellidos: apellidos.value,
            email: email.value,
            password: password.value
        });
        
        // Redirigir a la página de inicio de sesión
        window.location.href = 'login.html';
    });

    // Remover clase de error en input al escribir
    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', function () {
            this.classList.remove('input-error');
            errorMessage.textContent = '';
        });
    });
});