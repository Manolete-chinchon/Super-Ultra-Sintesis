CREATE DATABASE truplayer;
USE truplayer;

CREATE TABLE usuarios(
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25) NOT NULL,
    apellidos VARCHAR(25),
    email VARCHAR(25) UNIQUE NOT NULL,
    contrasena VARCHAR(25) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Tambien se podria usar DATETIME ¿Consulta cual es mejor?
);

CREATE TABLE productos(
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25) NOT NULL,
    descripcion VARCHAR(25),
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL,
    -- imagen VARCHAR(255)  ¿Pregunta si seria correcto para almacenar las rutas de la img.?
    fecha_agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
