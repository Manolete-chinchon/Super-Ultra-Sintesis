<?php
// Incluimos el archivo de conexión
require_once 'conexion.php';

// Iniciar la sesión
session_start();

// Comprobamos si se enviaron los datos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $email = trim($_POST['email']);
    $contrasena = trim($_POST['password']);

    if (empty($email) || empty($contrasena)) {
        echo "Por favor completa todos los campos.";
        exit();
    }

    // Verificar si el usuario ya existe
    $sql = "SELECT * FROM usuarios WHERE email = :email";
    $stmt = $conexion->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "El nombre de usuario ya está en uso. Por favor elige otro.";
        exit();
    }

    // Cifrar la contraseña
    $hashContrasena = password_hash($contrasena, PASSWORD_DEFAULT);

    // Insertar el nuevo usuario
    $sql = "INSERT INTO usuarios (nombre, email, contrasena) VALUES (:nombre, :email, :contrasena)";
    $stmt = $conexion->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':contrasena', $hashContrasena);

    if ($stmt->execute()) {
        echo "¡Registro exitoso! Ahora puedes <a href='login.html'>Iniciar sesión</a>.";
    } else {
        echo "Error al registrar el usuario. Inténtalo de nuevo.";
    }
} else {
    echo "Acceso no autorizado.";
}
?>