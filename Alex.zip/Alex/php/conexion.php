<?php
$servidor = "localhost";
$usuario_db = "root";  // Cambia esto si tienes otro usuario en MySQL
$password_db = "";     // Cambia esto si tienes una contraseña en MySQL
$base_datos = "truplayer";

$conn = new mysqli($servidor, $usuario_db, $password_db, $base_datos);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$conn->set_charset("utf8"); // Asegurar codificación UTF-8
?>
