<?php
// Incluimos el archivo de conexión
require_once 'conexion.php';

// Iniciar la sesión
session_start();

// Comprobamos si se enviaron los datos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($nombre) || empty($password)) {
        echo "Por favor completa todos los campos.";
        exit();
    }

    // Buscamos el usuario en la base de datos
    $sql = "SELECT * FROM nombre WHERE nombre = :nombre";
    $stmt = $conexion->prepare($sql);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $nombreData = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar la contraseña
        if (password_verify($password, $nombreData['password'])) {
            // Guardar datos en la sesión
            $_SESSION['nombre'] = $nombreData['nombre'];
            echo "¡Login exitoso! Bienvenido, " . htmlspecialchars($nombreData['usuario']) . ".";
            // Aquí podrías redirigir al usuario, por ejemplo:
            header('Location: index.php');
            // exit();
        } else {
            echo "Contraseña incorrecta.";
        }
    } else {
        echo "Usuario no encontrado.";
    }
} else {
    echo "Acceso no autorizado.";
}
?>
